package com.graded16.TicketBooking.Model;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TicketRepo extends JpaRepository<TicketModel, Integer>{

}
