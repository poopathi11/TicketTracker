package com.graded16.TicketBooking.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.graded16.TicketBooking.Model.TicketModel;
import com.graded16.TicketBooking.Model.TicketService;

@Controller
public class TicketController {
	
	@Autowired
	TicketService service;
	
	@RequestMapping("/")
	public String home() {
		return "home";
	}
	@RequestMapping("/ticket")
	public String ticketMap(Model data) {
		List<TicketModel> TM=service.getAllTicket();
		data.addAttribute("tm", TM);
		return "ticket";
	}
	@RequestMapping("/newticket")
	public String newTicketMap() {
		return "newticket";
	}
	@PostMapping("/createTicket")
	public String createTicket(@RequestParam String ticketTitle,@RequestParam String description ,@RequestParam String content,Model data) {
		 LocalDate currentDate = LocalDate.now();
		TicketModel tm=new TicketModel(0, ticketTitle, description, currentDate, content);
		service.addTicket(tm);
		List<TicketModel> TM=service.getAllTicket();
		data.addAttribute("tm", TM);
		return "ticket";
	}
	@PostMapping("/search")
	public String search(@RequestParam String ticketTitle,Model data) {
		TicketModel tm=new TicketModel(0, ticketTitle, "", null, "");
		List<TicketModel> TM=service.fileterByTicket(ticketTitle);
		data.addAttribute("tm", TM);
		return "ticket";
	} 
	@GetMapping("/update")
	public String update(@RequestParam int id,Model data) {
		TicketModel tm= service.getByID(id);
		data.addAttribute("tm", tm);		
		return "edit";
	} 
	@PostMapping("/updateTicket")
	public String updateTicket(@RequestParam int id,@RequestParam String ticketTitle,@RequestParam String description ,@RequestParam String content,Model data) {
		 LocalDate currentDate = LocalDate.now();
		TicketModel tm=new TicketModel(id, ticketTitle, description, currentDate, content);
		service.updateTicket(tm);
		List<TicketModel> TM=service.getAllTicket();
		data.addAttribute("tm", TM);
		return "ticket";
	}
	@GetMapping("/delete")
	public String delete(@RequestParam int id, Model data) {
		TicketModel tm=new TicketModel(id, null, null, null, null);
		service.deleteTicket(tm);
		List<TicketModel> TM=service.getAllTicket();
		data.addAttribute("tm", TM);
		return "ticket";
	}
	@RequestMapping("/view")
	public String view(@RequestParam int id,Model data) {
		TicketModel tm= service.getByID(id);
		data.addAttribute("tm", tm);
		return "viewdata";
	} 
} 
