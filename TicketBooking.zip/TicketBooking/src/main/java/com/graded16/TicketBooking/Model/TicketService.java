package com.graded16.TicketBooking.Model;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.stereotype.Service;

@Service
public class TicketService {

	@Autowired
	TicketRepo repo;
	
	public void addTicket(TicketModel ticket) {
		repo.save(ticket);
	}
	public void updateTicket(TicketModel ticket) {
		repo.save(ticket);
	} 
	public void deleteTicket(TicketModel ticket) {
		repo.delete(ticket);
	}
	public List<TicketModel> getAllTicket(){
		return repo.findAll();
	}
	public TicketModel getByID(int id) {
		Optional<TicketModel> ticketopt =repo.findById(id);
		TicketModel temp=null;
		if(ticketopt.get()!=null) {
			temp= ticketopt.get();
		}
			return temp;
	}
	public List<TicketModel> fileterByTicket(String searckey){
		//create dummy
		TicketModel tm=new TicketModel();
		tm.setTicketTitle(searckey);
		//where with ExampleMatcher
		ExampleMatcher em=ExampleMatcher.matching().withMatcher("ticketTitle", ExampleMatcher.GenericPropertyMatchers.contains()).withIgnorePaths("id","description","bookingDate","content");
		//make combining where with dummy
		Example<TicketModel> example=Example.of(tm,em);
		
		return repo.findAll(example);
	
	}
}
